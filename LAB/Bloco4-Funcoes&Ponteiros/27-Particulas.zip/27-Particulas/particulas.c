#include <stdio.h>
#include <stdbool.h>

void Cria_Particula(char Particula, int x, int y,char Matriz[32][64]);
void Zera_Matriz(char Matriz[32][64]);
void Copia_Matriz(char Matriz_Destino[32][64], char Matriz_Original[32][64]);
void Imprime_Matriz(char Matriz[32][64]);
void Atualiza_Fisica(char Matriz_Frame[32][64]);

int main() {
  char Matriz_Frame[32][64];
  int n_frames, frame, x, y;
  char nova_particula;

  Zera_Matriz(Matriz_Frame);

  scanf("%d", &n_frames);

  int contador = 0;
  while (contador < n_frames) {
    int n_lido = scanf(" %d: %d %d %c", &frame, &x, &y, &nova_particula);
    
    if (n_lido == EOF)
      frame = n_frames;
    
    while (contador < frame) {
      printf("frame: %d\n", contador + 1);
      Imprime_Matriz(Matriz_Frame);
      Atualiza_Fisica(Matriz_Frame);
      contador++;
    }
    
    if (n_lido != EOF) {
      Cria_Particula(nova_particula, x, y, Matriz_Frame);
    }
  }

  return 0;
}

void Cria_Particula(char Particula, int x, int y, char Matriz[32][64]) {
  Matriz[y][x] = Particula;
}

void Zera_Matriz(char Matriz[32][64]) {
  for (int i = 0; i < 32; i++) {
    for (int j = 0; j < 64; j++) {
      Matriz[i][j] = ' ';
    }
  }
}

void Copia_Matriz(char Matriz_Destino[32][64], char Matriz_Original[32][64]) {
  for (int i = 0; i < 32; i++) {
    for (int j = 0; j < 64; j++) {
      Matriz_Destino[i][j] = Matriz_Original[i][j]; 
    }
  }
}

void Imprime_Matriz(char Matriz[32][64]) {
  for (int i = 0; i < 32; i++) {
    for (int j = 0; j < 64; j++) {
      printf("%c", Matriz[i][j]);
    }
    printf("\n");
  }
}

void Atualiza_Fisica(char Matriz_Frame[32][64]) {
  char Matriz_Copia[32][64];
  char encontrado = false;

  Copia_Matriz(Matriz_Copia, Matriz_Frame);

  for (int i = 0; i < 32; i++) {
    for(int j = 0; j < 64; j++) {
      char *comparador[5][2];
      char Borda = '@';

      comparador[0][0] = (i == 31) ? &Borda : &Matriz_Frame[i + 1][j];
      comparador[1][0] = (i == 31 || j == 0) ? &Borda : &Matriz_Frame[i + 1][j - 1];
      comparador[2][0] = (i == 31 || j == 63) ? &Borda : &Matriz_Frame[i + 1][j + 1];
      comparador[3][0] = (j == 0) ? &Borda : &Matriz_Frame[i][j - 1];
      comparador[4][0] = (j == 63) ? &Borda : &Matriz_Frame[i][j + 1];

      comparador[0][1] = (i == 31) ? &Borda : &Matriz_Copia[i + 1][j];
      comparador[1][1] = (i == 31 || j == 0) ? &Borda : &Matriz_Copia[i + 1][j - 1];
      comparador[2][1] = (i == 31 || j == 63) ? &Borda : &Matriz_Copia[i + 1][j + 1];
      comparador[3][1] = (j == 0) ? &Borda : &Matriz_Copia[i][j - 1];
      comparador[4][1] = (j == 63) ? &Borda : &Matriz_Copia[i][j + 1];

      switch(Matriz_Frame[i][j]) {
        case '#':
          for (int k = 0; k < 3 && !encontrado; k++) {
            if (*comparador[k][0] == '~' || *comparador[k][0] == ' ') {
              *comparador[k][1] = Matriz_Frame[i][j];
              Matriz_Copia[i][j] = *comparador[k][0];
              encontrado = true;
            }
          }
          encontrado = false;
          break;
        case '~':
          for (int k = 0; k < 5 && !encontrado; k++) {
            if (*comparador[k][0] == ' ') {
              *comparador[k][1] = Matriz_Frame[i][j];
              Matriz_Copia[i][j] = *comparador[k][0];
              encontrado = true;
            }
          }
          encontrado = false;
          break;
      }
    }
  }

  Copia_Matriz(Matriz_Frame, Matriz_Copia);
}